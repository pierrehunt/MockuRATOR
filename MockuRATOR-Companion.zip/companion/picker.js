/* MockuGrab element picker — hover to highlight, click to capture, Esc to cancel */
(function () {
  if (window.__mkuPick) return; window.__mkuPick = 1;
  const ov = document.createElement('div');
  ov.style.cssText = 'position:fixed;z-index:2147483647;pointer-events:none;' +
    'outline:2px solid #e0342b;background:rgba(224,52,43,.08);border-radius:2px;' +
    'box-shadow:0 0 0 4000px rgba(30,28,23,.12)';
  document.documentElement.appendChild(ov);
  let cur = null;
  const move = (e) => {
    const el = document.elementFromPoint(e.clientX, e.clientY);
    if (!el || el === ov) return;
    cur = el;
    const r = el.getBoundingClientRect();
    ov.style.left = r.left + 'px'; ov.style.top = r.top + 'px';
    ov.style.width = r.width + 'px'; ov.style.height = r.height + 'px';
  };
  const done = (e) => {
    e.preventDefault(); e.stopPropagation();
    if (cur) {
      const r = cur.getBoundingClientRect();
      chrome.runtime.sendMessage({ type: 'mockupick', clip: {
        x: Math.max(0, r.left + window.scrollX - 4),
        y: Math.max(0, r.top + window.scrollY - 4),
        width: Math.max(1, r.width + 8),
        height: Math.max(1, r.height + 8)
      }});
    }
    cleanup();
  };
  const key = (e) => { if (e.key === 'Escape') cleanup(); };
  function cleanup() {
    ov.remove();
    removeEventListener('mousemove', move, true);
    removeEventListener('click', done, true);
    removeEventListener('keydown', key, true);
    delete window.__mkuPick;
  }
  addEventListener('mousemove', move, true);
  addEventListener('click', done, true);
  addEventListener('keydown', key, true);
})();
