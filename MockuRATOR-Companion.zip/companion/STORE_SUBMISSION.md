# Chrome Web Store submission kit

**Name:** MockuRATOR Companion — Snap · Grab · Log
**Category:** Developer Tools · **Price:** Free
**Summary (132 chars):** Full-page screenshots, element capture, and console/network recording — one right-click. Free, open source, no accounts.

**Permission justifications (the review will ask):**
- `debugger` — used solely to call Page.captureScreenshot for seamless full-page/element PNGs; attached only during the click, detached immediately; no other CDP commands issued.
- `downloads` — saves the captured PNG / recorded .txt log locally. Nothing is uploaded anywhere.
- `scripting` + `<all_urls>` — injects the element-highlight picker and the local MockuLog recorder on the user's explicit right-click only.
- **Privacy:** zero network calls, zero analytics, zero storage of user data. All output stays on the user's disk. Source: github.com/pierrehunt/MockuRATOR.

**Steps:** pay the one-time $5 dev fee at the Chrome Web Store dashboard → New item → upload this folder as a zip → paste the above → add 3 screenshots (capture the context menu, a full-page result, the REC badge) → submit. Reviews for debugger-permission extensions can take longer; the justification above addresses it head-on.
