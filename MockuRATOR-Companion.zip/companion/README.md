# MockuRATOR Companion — Snap · Grab · Log

One extension, three powers, on every page:

- **📸 MockuSnap** — toolbar click (or right-click menu): the ENTIRE page as one seamless PNG, no scrolling, no stitching.
- **🎯 MockuGrab** — right-click → capture an element: hover highlights, click downloads it pre-cut. Works even on strict-CSP sites that block the bookmarklet, because extensions are exempt.
- **🪲 MockuLog** — right-click → arm the recorder (badge shows REC); right-click again → the log downloads. No bookmarklet, no reload ritual — it injects into the real page context instantly.

Every file is named `mocku…-<site>-<page>-<time>` so dropping it onto a MockuRATOR board fills your report's Context automatically.

## Install (once, ~30 seconds)
1. Unzip this folder somewhere permanent (e.g. `Documents\MockuRATOR-Companion`).
2. `chrome://extensions` → toggle **Developer mode** (top right).
3. **Load unpacked** → select the folder. Pin the icon.

## About "proper" installs
Chrome only allows one-click installs from the Chrome Web Store ($5 one-time developer fee + a review). See `STORE_SUBMISSION.md` — everything needed to publish is prepared. Until then, load-unpacked is permanent and fully functional; Chrome may occasionally ask about developer-mode extensions on startup — click "keep".

## Honest limits
`chrome://` pages and the Web Store itself refuse capture (red `!`). Pages taller than ~16,000px get capped by the renderer. The brief "is debugging this browser" bar during capture is Chrome's seatbelt — normal.

MIT · https://pierrehunt.github.io/MockuRATOR/
