/* MockuRATOR Companion v2.0.0 — Snap · Grab · Log
 * https://pierrehunt.github.io/MockuRATOR/ · MIT */
const slugOf = (u) => {
  try { const x = new URL(u);
    return x.hostname + (x.pathname.replace(/[^a-zA-Z0-9]+/g,'-').replace(/^-+|-+$/g,'').slice(0,40) || 'home');
  } catch (e) { return 'page'; }
};
const flash = (tabId, text, color) => {
  chrome.action.setBadgeBackgroundColor({ color, tabId });
  chrome.action.setBadgeText({ text, tabId });
  setTimeout(() => chrome.action.setBadgeText({ text: '', tabId }), 2500);
};

async function capture(tab, clip, prefix) {
  const target = { tabId: tab.id };
  try {
    await chrome.debugger.attach(target, '1.3');
    const params = { format: 'png', captureBeyondViewport: true };
    if (clip) params.clip = { x: clip.x, y: clip.y, width: clip.width, height: clip.height, scale: 1 };
    const { data } = await chrome.debugger.sendCommand(target, 'Page.captureScreenshot', params);
    await chrome.downloads.download({
      url: 'data:image/png;base64,' + data,
      filename: prefix + '-' + slugOf(tab.url) + '-' + Date.now() + '.png',
      saveAs: false
    });
    flash(tab.id, '\u2713', '#16a34a');
  } catch (err) {
    flash(tab.id, '!', '#e0342b');
    console.warn('Companion:', err && err.message);
  } finally {
    try { await chrome.debugger.detach(target); } catch (e) {}
  }
}

chrome.action.onClicked.addListener((tab) => { if (tab && tab.id) capture(tab, null, 'mockusnap'); });

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({ id: 'snap', title: '📸 MockuSnap — capture full page', contexts: ['all'] });
  chrome.contextMenus.create({ id: 'grab', title: '🎯 MockuGrab — capture an element', contexts: ['all'] });
  chrome.contextMenus.create({ id: 'log',  title: '🪲 MockuLog — arm recorder / save log', contexts: ['all'] });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!tab || !tab.id) return;
  if (info.menuItemId === 'snap') return capture(tab, null, 'mockusnap');
  if (info.menuItemId === 'grab') {
    return chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['picker.js'] });
  }
  if (info.menuItemId === 'log') {
    // If the recorder is live, save; otherwise inject it (MAIN world = real console, CSP-exempt)
    const [probe] = await chrome.scripting.executeScript({
      target: { tabId: tab.id }, world: 'MAIN',
      func: () => { if (window.__mkuLog) { window.__mkuLog.save(); return 'saved'; } return 'absent'; }
    });
    if (probe && probe.result === 'absent') {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', files: ['mockulog.js'] });
      flash(tab.id, 'REC', '#f59e0b');
    } else flash(tab.id, '\u2713', '#16a34a');
  }
});

chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg && msg.type === 'mockupick' && sender.tab) capture(sender.tab, msg.clip, 'mockugrab');
});
